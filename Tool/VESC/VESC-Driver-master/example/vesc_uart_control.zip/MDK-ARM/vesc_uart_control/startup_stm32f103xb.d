vesc_uart_control\startup_stm32f103xb.o: startup_stm32f103xb.s
